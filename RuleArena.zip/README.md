# RuleArena

Dataset and code for paper "[RuleArena: A Benchmark for Rule-Guided Reasoning with LLMs in Real-World Scenarios](https://arxiv.org/abs/2412.08972)".

## Introduction

RuleArena is a challenging benchmark to evaluate LLMs on rule-guided reasoning tasks from real-world scenarios:
* **Airline:** Calculate the total cost for passengers, including their flight ticket and checked baggage fees.
* **NBA:** Determine whether one or more specified transactions (contract signing or trading) are allowed.
* **Tax:** Calculate the income tax for one person or family given their financial information.

<div style="text-align: center;">
  <img src="assets/framework.png" width="80%"></img>
</div>

## How to Use

#### Main Results
Simply enter the domain ([`airline`](airline/), [`nba`](nba/), or [`tax`](tax/)) folder and run the evaluation script `auto_test.py`, and specify:
* The LLM (`--llm`) to evaluate
* The difficulty level (`--complexity`) of problems
* Whether to use 1-shot example (`--use_example`)

For example, to evaluate Claude-3.5 Sonnet (`claude-3-5-sonnet-20241022`) on Level-1 (medium difficulty) airline tasks with 1-shot example, do the following:
```bash
cd ./airline
python auto_test.py --llm claude-3-5-sonnet-20241022 --complexity 1 --use_example
```

#### Experiments for Different Rule Representation
To run rule representation experiments, add `--textual` to convert tabular rules into textual rules when running airline and tax evaluations at difficulty level 0 like:
```bash
cd ./airline
python auto_test.py --llm claude-3-5-sonnet-20241022 --complexity 0 --use_example --textual
```

#### Experiments for Distractive Rules
To run distractive rule experiments, add `--distractor` or `--placeholder` to insert distractive rules or meaningless placeholder tokens when running tax evaluations at difficulty level 0 like:
```bash
cd ./tax
python auto_test.py --llm claude-3-5-sonnet-20241022 --complexity 0 --use_example --distractor
python auto_test.py --llm claude-3-5-sonnet-20241022 --complexity 0 --use_example --placeholder
```

**DO NOT use this two arguments together.**

#### Notes:
* The meanings of each parsable argument are written in comments.
* For LLMs except Llama, we use official APIs, for which you can refer to:
  - GPT-4o: [OpenAI API documents](https://platform.openai.com/docs/api-reference/introduction)
  - Claude-3.5 Sonnet: [Anthropic API documents](https://docs.anthropic.com/en/api/getting-started)
  - Qwen-2.5: [Qwen API documents](https://www.alibabacloud.com/help/en/model-studio/developer-reference/use-qwen-by-calling-api)
* Specifically, for Llama APIs you can refer to: [Vertex AI Llama API](https://console.cloud.google.com/vertex-ai/publishers/meta/model-garden/llama3_1?inv=1&invt=AbkkqQ&project=vast-art-443608-e4)

## Citation

Please consider citing our paper and giving us a star if you use RuleArena and find it interesting/helpful for your work, we'd appreciate it! Feel free to contact [Ruiwen Zhou](skyriver@sjtu.edu.cn) or open an issue if you have any questions.

```
@article{zhou2024rulearena,
  author={Ruiwen Zhou and Wenyue Hua and Liangming Pan and Sitao Cheng and Xiaobao Wu and En Yu and William Yang Wang},
  title={RuleArena: A Benchmark for Rule-Guided Reasoning with LLMs in Real-World Scenarios},
  journal={arXiv preprint arXiv:2412.08972},
  year={2024}
}
```
